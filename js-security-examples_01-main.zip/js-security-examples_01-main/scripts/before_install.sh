#!/bin/bash
# Perform any pre-deployment cleanup or checks
# Example: Remove old files
sudo rm -rf /var/www/html/*